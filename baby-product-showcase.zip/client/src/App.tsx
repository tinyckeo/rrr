import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ScenarioDetail from "./pages/ScenarioDetail";
import ProductDetail from "./pages/ProductDetail";
import StoryDetail from "./pages/StoryDetail";
import Timeline from "./pages/Timeline";
import SceneDetailPage from "./pages/SceneDetail";
import Knowledge from "./pages/Knowledge";
import KnowledgeDetail from "./pages/KnowledgeDetail";


function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/scenario/:id"} component={ScenarioDetail} />
      <Route path={"/product/:id"} component={ProductDetail} />
      <Route path={"/story/:id"} component={StoryDetail} />
      <Route path={"/timeline"} component={Timeline} />
      <Route path={"/scene/:id"} component={SceneDetailPage} />
      <Route path={"/knowledge"} component={Knowledge} />
      <Route path={"/knowledge/:id"} component={KnowledgeDetail} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

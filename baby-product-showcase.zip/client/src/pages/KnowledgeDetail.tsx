import { useParams, Link } from "wouter";
import { getKnowledgeById, knowledgeArticles } from "@/lib/knowledge";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function KnowledgeDetail() {
  const params = useParams<{ id: string }>();
  const article = getKnowledgeById(params.id || "");
  
  const relatedArticles = article
    ? knowledgeArticles.filter(
        a => a.ageRange === article.ageRange && a.id !== article.id
      ).slice(0, 3)
    : [];

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">文章未找到</h1>
          <Link href="/knowledge">
            <a className="btn-primary">返回知識中心</a>
          </Link>
        </div>
      </div>
    );
  }

  const categoryLabel = {
    milestone: '發展里程碑',
    nutrition: '營養指南',
    technique: '進食技巧',
    safety: '安全提示',
    faq: '常見問題'
  }[article.category];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/knowledge">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
              <span className="font-semibold text-foreground">返回</span>
            </a>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <button className="btn-primary text-sm">購物</button>
        </div>
      </nav>

      {/* Article Header */}
      <section className="py-8 md:py-12 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-3xl">{article.icon}</span>
            <div>
              <p className="text-sm text-muted-foreground">{categoryLabel}</p>
              <p className="text-sm text-muted-foreground">{article.ageRange}</p>
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            {article.title}
          </h1>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-xl p-8 md:p-12 border border-border">
              <div className="prose prose-lg max-w-none">
                <div className="text-lg text-muted-foreground leading-relaxed whitespace-pre-wrap mb-8">
                  {article.content}
                </div>
              </div>

              {/* Expert Info */}
              {article.expert && (
                <div className="mt-12 pt-8 border-t border-border">
                  <div className="bg-primary/10 rounded-lg p-6">
                    <p className="text-sm text-primary font-semibold mb-2">
                      👨‍⚕️ 專家建議
                    </p>
                    <p className="text-foreground">
                      本文由 <span className="font-bold">{article.expert}</span> 提供專業建議
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="py-16 md:py-24 bg-secondary/5">
          <div className="container">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-8">
              同階段相關文章
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedArticles.map((related) => (
                <Link key={related.id} href={`/knowledge/${related.id}`}>
                  <a className="bg-white rounded-xl p-6 border border-border hover:shadow-lg transition-shadow">
                    <div className="text-3xl mb-3">{related.icon}</div>
                    <h3 className="font-bold text-foreground mb-2 line-clamp-2">
                      {related.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {related.content.substring(0, 80)}...
                    </p>
                    <div className="flex items-center text-primary font-medium text-sm">
                      閱讀更多 <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </a>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            準備好開始了嗎？
          </h2>
          <p className="text-lg mb-6 opacity-90">
            選擇適合寶寶的產品，開始美好的成長旅程
          </p>
          <button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 px-8 py-3 rounded-lg font-bold transition-all duration-200">
            立即購物 <ChevronRight className="w-5 h-5 ml-2 inline" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                互動式育兒學習平台
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">功能</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">互動時間軸</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">知識中心</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">專家建議</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

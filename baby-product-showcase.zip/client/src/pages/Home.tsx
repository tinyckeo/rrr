import { useState } from "react";
import { Link } from "wouter";
import { knowledgeArticles, expertAdvices } from "@/lib/knowledge";
import { interactiveScenes } from "@/lib/scenes";
import { ChevronRight, Zap, BookOpen, Users } from "lucide-react";

export default function Home() {
  const [selectedAge, setSelectedAge] = useState(6);

  const ageRanges = [
    { value: 4, label: '4個月' },
    { value: 6, label: '6個月' },
    { value: 8, label: '8個月' },
    { value: 10, label: '10個月' },
    { value: 12, label: '12個月' },
    { value: 18, label: '18個月' },
    { value: 24, label: '24個月' }
  ];

  const getAgeRangeLabel = (age: number) => {
    if (age === 4) return '4-6個月';
    if (age === 6) return '6-8個月';
    if (age === 8) return '8-10個月';
    if (age === 10) return '10-12個月';
    if (age === 12) return '12-18個月';
    if (age === 18) return '18-24個月';
    return '24個月';
  };

  const currentAgeRange = getAgeRangeLabel(selectedAge);
  const relevantKnowledge = knowledgeArticles.filter(k => k.ageRange === currentAgeRange).slice(0, 2);
  const relevantScene = interactiveScenes.find(s => s.ageRange === currentAgeRange);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#interactive" className="text-foreground hover:text-primary transition-colors">
              互動
            </a>
            <a href="#knowledge" className="text-foreground hover:text-primary transition-colors">
              知識
            </a>
            <button className="btn-primary text-sm">
              購物
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Banner */}
      <section className="hero-section relative h-screen flex items-center">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/hero-banner-UCSV3DaCo95TUYmBbs2fsj.webp"
          alt="Hero Banner"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent" />
        <div className="container relative z-10">
          <div className="max-w-2xl">
            <div className="inline-block bg-secondary/20 text-secondary-foreground px-4 py-2 rounded-full text-sm font-medium mb-6">
              🎓 互動式學習平台
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
              發現適合寶寶<br />的每一步成長
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-xl">
              通過互動式情境模擬和專業育兒知識，陪伴您和寶寶度過每個重要時刻
            </p>
            <a href="#interactive" className="btn-primary inline-flex items-center">
              開始探索 <ChevronRight className="w-5 h-5 ml-2" />
            </a>
          </div>
        </div>
      </section>

      {/* Interactive Timeline Section */}
      <section id="interactive" className="py-16 md:py-24">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              寶寶成長時間軸
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              選擇寶寶的月齡，探索該階段的發展、知識和產品推薦
            </p>
          </div>

          {/* Age Slider */}
          <div className="bg-white rounded-xl p-8 shadow-sm border border-border mb-12">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-bold text-foreground">寶寶月齡</span>
                <span className="text-3xl font-bold text-primary">{selectedAge}個月</span>
              </div>
              <input
                type="range"
                min="4"
                max="24"
                step="2"
                value={selectedAge}
                onChange={(e) => setSelectedAge(parseInt(e.target.value))}
                className="w-full h-3 bg-secondary/20 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between mt-4 text-sm text-muted-foreground">
                <span>4個月</span>
                <span>24個月</span>
              </div>
            </div>

            {/* Quick Select Buttons */}
            <div className="flex flex-wrap gap-3">
              {ageRanges.map((range) => (
                <button
                  key={range.value}
                  onClick={() => setSelectedAge(range.value)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedAge === range.value
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary/10 text-foreground hover:bg-secondary/20'
                  }`}
                >
                  {range.label}
                </button>
              ))}
            </div>
          </div>

          {/* Age Range Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Scene */}
            {relevantScene && (
              <div className="lg:col-span-2">
                <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-border">
                  <div className="relative h-80 bg-muted overflow-hidden">
                    <img
                      src={relevantScene.image}
                      alt={relevantScene.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-8">
                    <div className="text-sm text-muted-foreground mb-2">📍 互動場景</div>
                    <h3 className="text-2xl font-bold text-foreground mb-3">
                      {relevantScene.title}
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      {relevantScene.description}
                    </p>
                    <Link href={`/scene/${relevantScene.id}`}>
                      <a className="btn-primary inline-flex items-center">
                        進入互動場景 <ChevronRight className="w-5 h-5 ml-2" />
                      </a>
                    </Link>
                  </div>
                </div>
              </div>
            )}

            {/* Knowledge Cards */}
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-primary" />
                  該階段知識
                </h3>
                <div className="space-y-3">
                  {relevantKnowledge.map((article) => (
                    <Link key={article.id} href={`/knowledge/${article.id}`}>
                      <a className="block p-4 bg-white rounded-lg border border-border hover:shadow-md transition-shadow">
                        <div className="text-2xl mb-2">{article.icon}</div>
                        <p className="font-semibold text-foreground text-sm line-clamp-2">
                          {article.title}
                        </p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {article.category === 'milestone' && '發展里程碑'}
                          {article.category === 'nutrition' && '營養指南'}
                          {article.category === 'technique' && '進食技巧'}
                          {article.category === 'safety' && '安全提示'}
                          {article.category === 'faq' && '常見問題'}
                        </p>
                      </a>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Expert Advice */}
              <div>
                <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  專家建議
                </h3>
                <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
                  <p className="text-sm text-foreground font-semibold mb-2">
                    💡 專家提示
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {expertAdvices.find(e => e.ageRange === currentAgeRange)?.content ||
                      '這個階段是寶寶成長的重要時期，耐心和觀察很關鍵。'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Knowledge Center Preview */}
      <section id="knowledge" className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              育兒知識中心
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              專業的育兒知識、安全提示和常見問題解答
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '🥣', title: '副食品入門', desc: '了解如何安全地開始副食品' },
              { icon: '🍴', title: '進食技巧', desc: '教導寶寶自主進食的方法' },
              { icon: '⚠️', title: '安全提示', desc: '了解窒息風險和預防措施' },
              { icon: '🤧', title: '過敏預防', desc: '識別和預防食物過敏' },
              { icon: '❓', title: '常見問題', desc: '解答父母最常見的疑惑' },
              { icon: '📚', title: '營養指南', desc: '確保寶寶獲得均衡營養' }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 border border-border hover:shadow-lg transition-shadow">
                <div className="text-4xl mb-3">{item.icon}</div>
                <h3 className="font-bold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/knowledge">
              <a className="btn-primary inline-flex items-center">
                查看完整知識庫 <ChevronRight className="w-5 h-5 ml-2" />
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">互動式體驗</h3>
              <p className="text-muted-foreground">
                通過拖動滑塊和點擊場景，探索寶寶每個月齡的發展和需求
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">專業知識</h3>
              <p className="text-muted-foreground">
                由兒科醫生、營養師和育兒專家提供的可靠建議
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">真實故事</h3>
              <p className="text-muted-foreground">
                聽聽其他家庭的真實經驗，發現貝親產品如何幫助他們
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            準備好開始了嗎？
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            選擇適合寶寶的產品，開始美好的成長旅程
          </p>
          <button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 px-8 py-3 rounded-lg font-bold transition-all duration-200">
            立即購物 <ChevronRight className="w-5 h-5 ml-2 inline" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                互動式育兒學習平台
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">功能</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#interactive" className="hover:text-primary transition-colors">互動時間軸</a></li>
                <li><a href="#knowledge" className="hover:text-primary transition-colors">知識中心</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">專家建議</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useParams, Link } from "wouter";
import { getSceneById } from "@/lib/scenes";
import { getKnowledgeById } from "@/lib/knowledge";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

export default function SceneDetail() {
  const params = useParams<{ id: string }>();
  const scene = getSceneById(params.id || "");
  const [selectedHotspot, setSelectedHotspot] = useState<string | null>(null);

  if (!scene) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">場景未找到</h1>
          <Link href="/">
            <a className="btn-primary">返回首頁</a>
          </Link>
        </div>
      </div>
    );
  }

  const selectedHotspotData = selectedHotspot
    ? scene.hotspots.find(h => h.id === selectedHotspot)
    : null;

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
              <span className="font-semibold text-foreground">返回</span>
            </a>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <button className="btn-primary text-sm">購物</button>
        </div>
      </nav>

      {/* Scene Title */}
      <section className="py-8 md:py-12 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container">
          <div className="text-sm text-muted-foreground mb-2">📍 互動場景</div>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-3">
            {scene.title}
          </h1>
          <p className="text-lg text-muted-foreground">
            {scene.description}
          </p>
        </div>
      </section>

      {/* Interactive Scene */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Scene Image with Hotspots */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-border">
                <div className="relative bg-muted">
                  <img
                    src={scene.image}
                    alt={scene.title}
                    className="w-full h-auto block"
                  />
                  {/* Hotspots */}
                  <div className="absolute inset-0">
                    {scene.hotspots.map((hotspot) => (
                      <button
                        key={hotspot.id}
                        onClick={() => setSelectedHotspot(hotspot.id)}
                        className={`absolute w-12 h-12 rounded-full flex items-center justify-center transition-all transform hover:scale-110 ${
                          selectedHotspot === hotspot.id
                            ? 'bg-primary ring-4 ring-primary/50'
                            : 'bg-primary/70 hover:bg-primary'
                        }`}
                        style={{
                          left: `${hotspot.x}%`,
                          top: `${hotspot.y}%`,
                          transform: 'translate(-50%, -50%)'
                        }}
                      >
                        <span className="text-white font-bold text-lg">+</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Instructions */}
                <div className="p-6 bg-secondary/5 border-t border-border">
                  <p className="text-sm text-muted-foreground">
                    💡 點擊場景中的 <span className="text-primary font-bold">+</span> 標記，了解產品如何在實際場景中使用
                  </p>
                </div>
              </div>
            </div>

            {/* Product Details */}
            <div className="space-y-6">
              {selectedHotspotData ? (
                <div className="bg-white rounded-xl p-6 border border-border shadow-sm">
                  <div className="text-sm text-muted-foreground mb-3">
                    🎯 選中的產品
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-3">
                    {selectedHotspotData.productName}
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    {selectedHotspotData.description}
                  </p>
                  <button className="btn-primary w-full">
                    查看產品詳情
                  </button>
                </div>
              ) : (
                <div className="bg-primary/10 rounded-xl p-6 border border-primary/20">
                  <div className="text-sm text-primary font-semibold mb-2">
                    👆 開始探索
                  </div>
                  <p className="text-sm text-foreground">
                    點擊場景中的標記，發現產品如何幫助寶寶在這個階段成長
                  </p>
                </div>
              )}

              {/* All Products in Scene */}
              <div>
                <h4 className="font-bold text-foreground mb-3">場景中的所有產品</h4>
                <div className="space-y-2">
                  {scene.hotspots.map((hotspot) => (
                    <button
                      key={hotspot.id}
                      onClick={() => setSelectedHotspot(hotspot.id)}
                      className={`w-full text-left p-3 rounded-lg border transition-all ${
                        selectedHotspot === hotspot.id
                          ? 'bg-primary/10 border-primary'
                          : 'bg-white border-border hover:bg-secondary/5'
                      }`}
                    >
                      <p className="font-semibold text-foreground text-sm">
                        {hotspot.productName}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                        {hotspot.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tips Section */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-8">
            💡 使用技巧
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {scene.tips.map((tip, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 border border-border">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-bold">{idx + 1}</span>
                  </div>
                  <p className="text-foreground">{tip}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Related Knowledge */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-8">
            📚 相關知識
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {scene.relatedKnowledge.map((knowledgeId) => {
              const knowledge = getKnowledgeById(knowledgeId);
              if (!knowledge) return null;
              return (
                <Link key={knowledgeId} href={`/knowledge/${knowledgeId}`}>
                  <a className="bg-white rounded-xl p-6 border border-border hover:shadow-lg transition-shadow">
                    <div className="text-3xl mb-3">{knowledge.icon}</div>
                    <h3 className="text-lg font-bold text-foreground mb-2">
                      {knowledge.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {knowledge.content.substring(0, 100)}...
                    </p>
                    <div className="flex items-center text-primary font-medium text-sm">
                      閱讀更多 <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                互動式育兒學習平台
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">功能</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">互動時間軸</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">知識中心</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">專家建議</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

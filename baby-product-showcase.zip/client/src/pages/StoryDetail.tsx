import { useParams, Link } from "wouter";
import { getStoryById, getRelatedStories } from "@/lib/stories";
import { ChevronLeft, ChevronRight, Heart } from "lucide-react";

export default function StoryDetail() {
  const params = useParams<{ id: string }>();
  const story = getStoryById(params.id || "");
  const relatedStories = story ? getRelatedStories(story.id) : [];

  if (!story) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">故事未找到</h1>
          <Link href="/">
            <a className="btn-primary">返回首頁</a>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
              <span className="font-semibold text-foreground">返回</span>
            </a>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <button className="btn-primary text-sm">購物</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-section relative h-96 flex items-end">
        <img
          src={story.heroImage}
          alt={story.title}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="container relative z-10 pb-8">
          <div className="inline-block bg-secondary/20 text-secondary-foreground px-4 py-2 rounded-full text-sm font-medium mb-4">
            {story.momName}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-2 leading-tight">
            {story.title}
          </h1>
          <p className="text-xl text-white/90">
            {story.subtitle}
          </p>
        </div>
      </section>

      {/* Family Card */}
      <section className="py-8">
        <div className="container">
          <div className="bg-white rounded-xl p-8 shadow-sm border border-border">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="text-sm text-muted-foreground mb-2">家庭名稱</div>
                <h3 className="text-2xl font-bold text-foreground">{story.familyName}</h3>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-2">寶寶信息</div>
                <p className="text-lg font-semibold text-foreground">
                  {story.babyName} · {story.babyAge}
                </p>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-2">家庭背景</div>
                <p className="text-foreground">{story.familyBackground}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Content */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="prose prose-lg max-w-none">
              <div className="text-lg text-muted-foreground leading-relaxed whitespace-pre-wrap mb-12">
                {story.storyContent}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Moments */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12">
            故事中的關鍵時刻
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {story.keyMoments.map((moment, idx) => (
              <div key={idx} className="rounded-xl overflow-hidden shadow-sm">
                <img
                  src={moment.image}
                  alt={moment.caption}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6 bg-white">
                  <p className="text-foreground font-semibold">{moment.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Used */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12">
            故事中使用的產品
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {story.products.map((product) => (
              <div key={product.id} className="bg-white rounded-xl p-8 border border-border hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-foreground mb-2">
                      {product.name}
                    </h3>
                    <p className="text-muted-foreground">
                      {product.role}
                    </p>
                  </div>
                  <Heart className="w-6 h-6 text-accent flex-shrink-0" />
                </div>
                <button className="btn-primary w-full mt-6">
                  查看產品詳情
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mom's Thoughts */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <div className="text-5xl mb-4">💭</div>
              <h2 className="text-3xl md:text-4xl font-bold mb-8">
                {story.momName}的心得
              </h2>
            </div>
            <p className="text-xl leading-relaxed text-center opacity-90">
              {story.momThoughts}
            </p>
          </div>
        </div>
      </section>

      {/* Related Stories */}
      {relatedStories.length > 0 && (
        <section className="py-16 md:py-24">
          <div className="container">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12">
              相關故事
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {relatedStories.map((relatedStory) => (
                <Link key={relatedStory.id} href={`/story/${relatedStory.id}`}>
                  <a className="story-card group">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={relatedStory.heroImage}
                        alt={relatedStory.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <h3 className="text-lg font-bold text-white line-clamp-2">
                          {relatedStory.title}
                        </h3>
                      </div>
                    </div>
                    <div className="p-4 bg-white">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          {relatedStory.momName}
                        </span>
                        <ChevronRight className="w-4 h-4 text-primary" />
                      </div>
                    </div>
                  </a>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            你也有故事要分享嗎？
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            分享你和寶寶使用貝親產品的故事，成為我們社群的一部分
          </p>
          <button className="btn-primary">
            分享你的故事 <ChevronRight className="w-5 h-5 ml-2 inline" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                每個家庭都有屬於自己的故事
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">故事</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">媽媽故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">成長時間軸</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">分享你的故事</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { Link } from "wouter";
import { knowledgeArticles, expertAdvices } from "@/lib/knowledge";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";

export default function Knowledge() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const categories = [
    { id: 'milestone', label: '發展里程碑', icon: '🌟' },
    { id: 'nutrition', label: '營養指南', icon: '🥗' },
    { id: 'technique', label: '進食技巧', icon: '🍴' },
    { id: 'safety', label: '安全提示', icon: '⚠️' },
    { id: 'faq', label: '常見問題', icon: '❓' }
  ];

  const filteredArticles = knowledgeArticles.filter(article => {
    const matchesCategory = !selectedCategory || article.category === selectedCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          article.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
              <span className="font-semibold text-foreground">返回</span>
            </a>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <button className="btn-primary text-sm">購物</button>
        </div>
      </nav>

      {/* Header */}
      <section className="py-8 md:py-12 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-3">
            育兒知識中心
          </h1>
          <p className="text-lg text-muted-foreground">
            專業的育兒知識、安全提示和常見問題解答
          </p>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 md:py-12">
        <div className="container">
          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="搜尋知識..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-8">
            <h3 className="font-bold text-foreground mb-4">按類別篩選</h3>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedCategory === null
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary/10 text-foreground hover:bg-secondary/20'
                }`}
              >
                全部
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
                    selectedCategory === cat.id
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary/10 text-foreground hover:bg-secondary/20'
                  }`}
                >
                  <span>{cat.icon}</span>
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.map((article) => (
              <Link key={article.id} href={`/knowledge/${article.id}`}>
                <a className="bg-white rounded-xl p-6 border border-border hover:shadow-lg transition-shadow h-full flex flex-col">
                  <div className="text-4xl mb-3">{article.icon}</div>
                  <h3 className="text-lg font-bold text-foreground mb-2 flex-grow">
                    {article.title}
                  </h3>
                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <span className="text-xs text-muted-foreground">
                      {article.ageRange}
                    </span>
                    <ChevronRight className="w-4 h-4 text-primary" />
                  </div>
                </a>
              </Link>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">
                沒有找到相關的知識文章
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Expert Advice Section */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-8">
            👨‍⚕️ 專家建議
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {expertAdvices.map((advice) => (
              <div key={advice.id} className="bg-white rounded-xl p-6 border border-border">
                <div className="text-3xl mb-3">{advice.icon}</div>
                <h3 className="text-lg font-bold text-foreground mb-2">
                  {advice.expertName}
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {advice.expertTitle}
                </p>
                <div className="bg-primary/10 rounded-lg p-4 mb-4">
                  <p className="text-sm font-semibold text-primary mb-2">
                    {advice.topic}
                  </p>
                  <p className="text-sm text-foreground">
                    {advice.content}
                  </p>
                </div>
                <p className="text-xs text-muted-foreground">
                  適用年齡：{advice.ageRange}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-8">
            常見問題
          </h2>
          <div className="max-w-3xl mx-auto space-y-4">
            {[
              {
                q: '什麼時候可以開始給寶寶吃副食品？',
                a: '通常在寶寶滿4-6個月時可以開始引入副食品。但最好先諮詢兒科醫生，確保寶寶已經準備好。'
              },
              {
                q: '如何知道寶寶是否準備好自主進食？',
                a: '當寶寶能夠坐直、對食物感興趣、並能用手抓東西時，就可以開始練習自主進食。'
              },
              {
                q: '寶寶拒絕吃新食物怎麼辦？',
                a: '這很正常，寶寶可能需要多次嘗試才會接受新食物。不要強迫，可以稍後再試，並讓寶寶看著你吃。'
              },
              {
                q: '如何預防寶寶窒息？',
                a: '避免給寶寶圓形、堅硬或粘稠的食物。確保食物軟到可以用手指輕易壓碎，並始終在寶寶身邊監督。'
              },
              {
                q: '寶寶進食時灑落很多食物，這正常嗎？',
                a: '完全正常！這是寶寶學習進食過程的一部分。隨著時間推移，寶寶會變得越來越熟練。'
              }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 border border-border">
                <h3 className="font-bold text-foreground mb-3">
                  {idx + 1}. {item.q}
                </h3>
                <p className="text-muted-foreground">
                  {item.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            有其他問題？
          </h2>
          <p className="text-lg mb-6 opacity-90">
            聯絡我們的育兒專家，獲得個性化的建議
          </p>
          <button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 px-8 py-3 rounded-lg font-bold transition-all duration-200">
            聯絡我們 <ChevronRight className="w-5 h-5 ml-2 inline" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                互動式育兒學習平台
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">功能</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">互動時間軸</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">知識中心</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">專家建議</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

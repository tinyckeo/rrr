import { useParams, Link } from "wouter";
import { getScenarioById, getProductsByScenario } from "@/lib/products";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function ScenarioDetail() {
  const params = useParams<{ id: string }>();
  const scenario = getScenarioById(params.id || "");
  const products = getProductsByScenario(params.id || "");

  if (!scenario) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground mb-4">情境未找到</h1>
          <Link href="/">
            <a className="btn-primary">返回首頁</a>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
              <span className="font-semibold text-foreground">返回</span>
            </a>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <button className="btn-primary text-sm">購物</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-section relative">
        <img
          src={scenario.heroImage}
          alt={scenario.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent flex items-end">
          <div className="container pb-12">
            <div className="inline-block bg-secondary/20 text-secondary-foreground px-4 py-2 rounded-full text-sm font-medium mb-4">
              {scenario.ageRange}
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
              {scenario.name}
            </h1>
            <p className="text-xl text-white/90 max-w-2xl">
              {scenario.description}
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              這個階段的寶寶
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              {scenario.story}
            </p>
            <div className="bg-secondary/10 border-l-4 border-secondary rounded-lg p-6">
              <h3 className="font-bold text-foreground mb-3">💡 貝親小貼士</h3>
              <p className="text-muted-foreground">
                在這個階段，選擇適合寶寶年齡的產品非常重要。貝親的所有產品都經過嚴格的安全測試，採用無毒、安全的材料，讓您可以放心為寶寶選擇。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12">
            推薦產品
          </h2>

          {products.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <div key={product.id} className="product-card group">
                  <div className="relative h-56 bg-muted overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-4 right-4 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-medium">
                      ${product.price}
                    </div>
                  </div>
                  <div className="p-6">
                    <div className="text-sm text-muted-foreground mb-2">
                      {product.ageRange}
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-3">
                      {product.name}
                    </h3>
                    <p className="text-muted-foreground mb-4 line-clamp-3">
                      {product.description}
                    </p>
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-foreground mb-2">
                        產品特色
                      </h4>
                      <ul className="space-y-1">
                        {product.features.slice(0, 3).map((feature, idx) => (
                          <li key={idx} className="text-sm text-muted-foreground flex items-start">
                            <span className="text-primary mr-2">✓</span>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <button className="btn-primary w-full">
                      查看詳情
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">
                這個情境暫無推薦產品
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Related Scenarios */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12">
            探索其他成長階段
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Placeholder for related scenarios */}
            <div className="bg-secondary/10 rounded-xl p-6 text-center">
              <p className="text-muted-foreground">
                <ChevronRight className="w-6 h-6 mx-auto mb-2 text-primary" />
                下一個階段
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            準備好了嗎？
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            選擇適合您寶寶的產品，開始美好的成長旅程
          </p>
          <button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 px-8 py-3 rounded-lg font-bold transition-all duration-200">
            立即購物 <ChevronRight className="w-5 h-5 ml-2 inline" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                陪伴寶寶每一步成長
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">產品</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">副食品用具</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">練習餐具</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">外出用品</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

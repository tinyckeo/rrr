import { Link } from "wouter";
import { stories } from "@/lib/stories";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function Timeline() {
  const ageRanges = [
    { range: '4-6個月', title: '開始副食品', icon: '🥣', description: '寶寶開始探索第一口食物' },
    { range: '6-8個月', title: '嘗試更多食物', icon: '🥗', description: '逐漸引入多種食材' },
    { range: '8-10個月', title: '學習自主進食', icon: '🍴', description: '寶寶開始用手抓食物' },
    { range: '10-12個月', title: '獨立進食訓練', icon: '🎉', description: '練習用餐具進食' },
    { range: '12-18個月', title: '多樣化飲食', icon: '🍽️', description: '嘗試家庭食物' },
    { range: '18-24個月', title: '完全自主進食', icon: '👶', description: '獨立進食和探索' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <ChevronLeft className="w-5 h-5" />
              <span className="font-semibold text-foreground">返回</span>
            </a>
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
              貝
            </div>
            <span className="font-bold text-lg text-foreground">貝親寶寶</span>
          </div>
          <button className="btn-primary text-sm">購物</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-4">
              寶寶成長時間軸
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              按月齡瀏覽故事和產品推薦，陪伴寶寶的每一個成長階段
            </p>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="relative">
            {/* Timeline Line */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-primary via-secondary to-accent" />

            {/* Timeline Items */}
            <div className="space-y-16">
              {ageRanges.map((item, idx) => {
                const itemStories = stories.filter(s => s.ageRange === item.range);
                return (
                  <div key={idx} className={`flex ${idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                    {/* Content */}
                    <div className="md:w-1/2 md:pr-12">
                      <div className="bg-white rounded-xl p-8 shadow-sm border border-border">
                        <div className="text-5xl mb-4">{item.icon}</div>
                        <div className="text-sm text-muted-foreground mb-2 font-semibold">
                          {item.range}
                        </div>
                        <h3 className="text-3xl font-bold text-foreground mb-2">
                          {item.title}
                        </h3>
                        <p className="text-muted-foreground mb-6">
                          {item.description}
                        </p>

                        {/* Stories for this age range */}
                        {itemStories.length > 0 && (
                          <div className="mt-6 pt-6 border-t border-border">
                            <h4 className="font-bold text-foreground mb-4">
                              這個階段的故事
                            </h4>
                            <div className="space-y-3">
                              {itemStories.map((story) => (
                                <Link key={story.id} href={`/story/${story.id}`}>
                                  <a className="flex items-center justify-between p-3 bg-secondary/5 rounded-lg hover:bg-secondary/10 transition-colors">
                                    <div>
                                      <p className="font-semibold text-foreground text-sm">
                                        {story.title}
                                      </p>
                                      <p className="text-xs text-muted-foreground">
                                        {story.momName}
                                      </p>
                                    </div>
                                    <ChevronRight className="w-4 h-4 text-primary" />
                                  </a>
                                </Link>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Timeline Dot */}
                    <div className="hidden md:flex md:w-1/2 items-center justify-center">
                      <div className="w-6 h-6 bg-primary rounded-full border-4 border-background shadow-lg" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Growth Tips */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center">
            育兒知識小貼士
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8">
              <div className="text-4xl mb-4">📚</div>
              <h3 className="text-xl font-bold text-foreground mb-3">
                副食品入門
              </h3>
              <p className="text-muted-foreground mb-4">
                了解如何安全地為寶寶引入副食品，選擇合適的食材和準備方法。
              </p>
              <a href="#" className="text-primary font-semibold text-sm hover:underline">
                了解更多 <ChevronRight className="w-4 h-4 inline ml-1" />
              </a>
            </div>

            <div className="bg-white rounded-xl p-8">
              <div className="text-4xl mb-4">🥄</div>
              <h3 className="text-xl font-bold text-foreground mb-3">
                自主進食訓練
              </h3>
              <p className="text-muted-foreground mb-4">
                掌握寶寶自主進食的關鍵階段和技巧，選擇合適的餐具。
              </p>
              <a href="#" className="text-primary font-semibold text-sm hover:underline">
                了解更多 <ChevronRight className="w-4 h-4 inline ml-1" />
              </a>
            </div>

            <div className="bg-white rounded-xl p-8">
              <div className="text-4xl mb-4">🍽️</div>
              <h3 className="text-xl font-bold text-foreground mb-3">
                營養均衡飲食
              </h3>
              <p className="text-muted-foreground mb-4">
                確保寶寶獲得全面的營養，了解各個成長階段的飲食需求。
              </p>
              <a href="#" className="text-primary font-semibold text-sm hover:underline">
                了解更多 <ChevronRight className="w-4 h-4 inline ml-1" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Product Recommendations */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center">
            各階段推薦產品
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { stage: '4-6個月', product: '食物調理工具組', icon: '🥣' },
              { stage: '6-8個月', product: '矽膠軟湯匙', icon: '🥄' },
              { stage: '8-10個月', product: '練習餐具套組', icon: '🍴' },
              { stage: '10-12個月', product: '便攜式餐具組', icon: '🎒' },
              { stage: '12-18個月', product: '多功能餐具組', icon: '🍽️' },
              { stage: '18-24個月', product: '防滑碗盤', icon: '🛡️' }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-8 border border-border hover:shadow-lg transition-shadow">
                <div className="text-5xl mb-4">{item.icon}</div>
                <div className="text-sm text-muted-foreground mb-2">{item.stage}</div>
                <h3 className="text-xl font-bold text-foreground mb-4">
                  {item.product}
                </h3>
                <button className="btn-primary w-full">
                  查看詳情
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-secondary/5">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center">
            常見問題
          </h2>

          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-white rounded-xl p-8">
              <h3 className="text-lg font-bold text-foreground mb-3">
                寶寶什麼時候可以開始吃副食品？
              </h3>
              <p className="text-muted-foreground">
                通常在寶寶滿6個月時可以開始引入副食品。但最好先諮詢兒科醫生，確保寶寶已經準備好。
              </p>
            </div>

            <div className="bg-white rounded-xl p-8">
              <h3 className="text-lg font-bold text-foreground mb-3">
                如何知道寶寶是否準備好自主進食？
              </h3>
              <p className="text-muted-foreground">
                當寶寶能夠坐直、對食物感興趣、並能用手抓東西時，就可以開始練習自主進食。
              </p>
            </div>

            <div className="bg-white rounded-xl p-8">
              <h3 className="text-lg font-bold text-foreground mb-3">
                貝親的產品是否安全無毒？
              </h3>
              <p className="text-muted-foreground">
                是的，所有貝親產品都採用安全、無毒的材料製造，並通過國際安全標準認證。
              </p>
            </div>

            <div className="bg-white rounded-xl p-8">
              <h3 className="text-lg font-bold text-foreground mb-3">
                我可以在哪裡購買貝親產品？
              </h3>
              <p className="text-muted-foreground">
                貝親產品可在各大母嬰用品店、線上購物平台和官方網站購買。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            準備好開始了嗎？
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            選擇適合寶寶的產品，開始美好的成長旅程
          </p>
          <button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 px-8 py-3 rounded-lg font-bold transition-all duration-200">
            立即購物 <ChevronRight className="w-5 h-5 ml-2 inline" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground/5 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                  貝
                </div>
                <span className="font-bold text-foreground">貝親寶寶</span>
              </div>
              <p className="text-sm text-muted-foreground">
                每個家庭都有屬於自己的故事
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">故事</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">媽媽故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">成長時間軸</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">分享你的故事</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">關於我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">品牌故事</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">安全認證</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">聯絡我們</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">追蹤我們</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">YouTube</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 貝親寶寶。版權所有。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

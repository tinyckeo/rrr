export interface Hotspot {
  id: string;
  x: number;
  y: number;
  productId: string;
  productName: string;
  description: string;
}

export interface InteractiveScene {
  id: string;
  title: string;
  description: string;
  ageRange: string;
  image: string;
  hotspots: Hotspot[];
  tips: string[];
  relatedKnowledge: string[];
}

export const interactiveScenes: InteractiveScene[] = [
  {
    id: 'scene-1',
    title: '家中進食場景：第一次副食品',
    description: '寶寶在家中高腳椅上享受第一口副食品的溫暖時刻',
    ageRange: '4-6個月',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-1-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    hotspots: [
      {
        id: 'hotspot-1',
        x: 30,
        y: 60,
        productId: 'product-1',
        productName: '食物調理工具組',
        description: '用於準備和調理副食品，確保食物安全和營養'
      },
      {
        id: 'hotspot-2',
        x: 50,
        y: 70,
        productId: 'product-2',
        productName: '矽膠軟湯匙',
        description: '溫柔地將食物送入寶寶嘴裡，保護牙齦'
      },
      {
        id: 'hotspot-3',
        x: 70,
        y: 50,
        productId: 'product-6',
        productName: '防滑碗盤',
        description: '穩定的碗盤設計，防止食物灑落'
      }
    ],
    tips: [
      '選擇寶寶精神最好的時候進食',
      '準備好清潔用品，會有一些灑落',
      '保持輕鬆愉快的氛圍',
      '不要強迫寶寶進食'
    ],
    relatedKnowledge: ['knowledge-1', 'knowledge-5']
  },
  {
    id: 'scene-2',
    title: '自主進食場景：學習用餐具',
    description: '寶寶開始學習用自己的小手和餐具進食',
    ageRange: '8-10個月',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-2-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    hotspots: [
      {
        id: 'hotspot-4',
        x: 40,
        y: 65,
        productId: 'product-5',
        productName: '練習餐具套組',
        description: '專為小手設計的餐具，易於握持和操作'
      },
      {
        id: 'hotspot-5',
        x: 60,
        y: 55,
        productId: 'product-6',
        productName: '防滑碗盤',
        description: '碗盤不易滑動，寶寶可以更容易地舀取食物'
      },
      {
        id: 'hotspot-6',
        x: 25,
        y: 45,
        productId: 'product-3',
        productName: '圍兜',
        description: '保護衣服，讓寶寶可以自由探索進食'
      }
    ],
    tips: [
      '允許寶寶自己嘗試，即使會灑落',
      '提供易握的食物塊',
      '坐在寶寶身邊提供支持',
      '表揚每一次嘗試'
    ],
    relatedKnowledge: ['knowledge-3', 'knowledge-4']
  },
  {
    id: 'scene-3',
    title: '外出用餐場景：便攜式解決方案',
    description: '在外出時為寶寶準備便攜式的進食解決方案',
    ageRange: '10-12個月',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-3-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    hotspots: [
      {
        id: 'hotspot-7',
        x: 35,
        y: 60,
        productId: 'product-3',
        productName: '便攜式餐具組',
        description: '輕巧易攜帶，隨時隨地為寶寶準備食物'
      },
      {
        id: 'hotspot-8',
        x: 55,
        y: 70,
        productId: 'product-4',
        productName: '便攜式食物容器',
        description: '保持食物新鮮和衛生，方便攜帶'
      },
      {
        id: 'hotspot-9',
        x: 70,
        y: 50,
        productId: 'product-3',
        productName: '圍兜',
        description: '輕便設計，外出時也能保護寶寶的衣服'
      }
    ],
    tips: [
      '提前準備好所有需要的物品',
      '選擇易於清潔的餐具',
      '帶上濕紙巾進行清潔',
      '選擇不易變質的食物'
    ],
    relatedKnowledge: ['knowledge-4']
  },
  {
    id: 'scene-4',
    title: '多寶家庭場景：同時照顧多個孩子',
    description: '在多寶家庭中有效地管理進食時間',
    ageRange: '12-24個月',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-4-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    hotspots: [
      {
        id: 'hotspot-10',
        x: 30,
        y: 65,
        productId: 'product-5',
        productName: '多功能餐具組',
        description: '適應不同發展階段寶寶的需求'
      },
      {
        id: 'hotspot-11',
        x: 60,
        y: 60,
        productId: 'product-6',
        productName: '防滑碗盤',
        description: '每個寶寶都有自己的碗盤，避免混淆'
      },
      {
        id: 'hotspot-12',
        x: 45,
        y: 40,
        productId: 'product-7',
        productName: '易握餐具',
        description: '不同大小的餐具適應不同年齡的寶寶'
      }
    ],
    tips: [
      '為每個寶寶準備適合其發展階段的餐具',
      '建立一致的進食時間表',
      '讓較大的孩子幫助照顧較小的孩子',
      '準備足夠的清潔用品'
    ],
    relatedKnowledge: ['knowledge-4']
  }
];

export function getSceneById(id: string): InteractiveScene | undefined {
  return interactiveScenes.find(scene => scene.id === id);
}

export function getScenesByAgeRange(ageRange: string): InteractiveScene[] {
  return interactiveScenes.filter(scene => scene.ageRange === ageRange);
}

export function getAllScenes(): InteractiveScene[] {
  return interactiveScenes;
}

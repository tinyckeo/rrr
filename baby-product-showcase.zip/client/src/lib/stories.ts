export interface Story {
  id: string;
  title: string;
  subtitle: string;
  familyName: string;
  momName: string;
  babyAge: string;
  babyName: string;
  familyBackground: string;
  heroImage: string;
  storyContent: string;
  keyMoments: Array<{
    image: string;
    caption: string;
  }>;
  products: Array<{
    id: string;
    name: string;
    role: string;
  }>;
  momThoughts: string;
  relatedStories: string[];
  ageRange: string;
  category: 'first-time' | 'working-mom' | 'multiple-kids' | 'grandparents';
}

export const stories: Story[] = [
  {
    id: 'story-1',
    title: '林媽媽的第一次副食品冒險',
    subtitle: '從緊張到享受，寶寶的第一口美食之旅',
    familyName: '林家',
    momName: '林媽媽',
    babyAge: '6個月',
    babyName: '小米',
    familyBackground: '新手媽媽，全職照顧寶寶，丈夫在科技公司上班',
    heroImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-1-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    storyContent: `小米滿6個月了，林媽媽開始準備寶寶的第一次副食品。看著各式各樣的餐具和工具，她既興奮又緊張。「會不會寶寶不喜歡？會不會我準備不好？」

第一天，林媽媽用貝親的副食品調理工具準備了簡單的米糊。小米坐在高腳椅上，眼睛閃閃發光地看著媽媽。當第一口米糊進入小米的嘴裡，那一刻，林媽媽的所有擔心都消散了。

「看著寶寶探索新的味道，我發現這不只是餵食，而是一場充滿愛的冒險。貝親的工具讓我能夠安心地為寶寶準備營養的食物，每一次都充滿了期待。」`,
    keyMoments: [
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-1-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '小米的第一口副食品，充滿期待的眼神'
      },
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-2-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '每天的副食品準備，成為我們最溫暖的時光'
      }
    ],
    products: [
      {
        id: 'product-1',
        name: '食物調理工具組',
        role: '幫助我輕鬆準備營養的副食品'
      },
      {
        id: 'product-2',
        name: '矽膠軟湯匙',
        role: '溫柔地引導寶寶開始進食'
      }
    ],
    momThoughts: '最初的擔心變成了享受。看著寶寶一天天成長，我感謝貝親的產品讓我能夠放心地陪伴這個過程。',
    relatedStories: ['story-2', 'story-3'],
    ageRange: '4-6個月',
    category: 'first-time'
  },
  {
    id: 'story-2',
    title: '王媽媽的職場媽媽日常',
    subtitle: '外出也能輕鬆餵食，工作和育兒的完美平衡',
    familyName: '王家',
    momName: '王媽媽',
    babyAge: '10個月',
    babyName: '小寶',
    familyBackground: '職業媽媽，行銷經理，需要經常出差和外出',
    heroImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-3-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    storyContent: `作為一名行銷經理，王媽媽的日程總是排得滿滿的。但自從小寶出生後，她最大的挑戰不是工作，而是如何在忙碌的工作中也能好好照顧寶寶。

「有時候我需要帶小寶去辦公室，或者在外面吃飯時給他準備食物。」王媽媽說。正是因為有了貝親的便攜式餐具和外出用品，她才能自信地在任何地方為小寶準備營養的食物。

小寶現在10個月了，已經可以自己拿著貝親的練習餐具嘗試進食。王媽媽發現，工作和育兒並不是對立的，只要有對的工具和心態，她可以在兩者之間找到平衡。`,
    keyMoments: [
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-3-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '在咖啡廳也能輕鬆為寶寶準備食物'
      },
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-4-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '小寶在練習自主進食，媽媽在一旁工作'
      }
    ],
    products: [
      {
        id: 'product-3',
        name: '便攜式餐具組',
        role: '讓我隨時隨地都能為寶寶準備食物'
      },
      {
        id: 'product-4',
        name: '練習餐具套組',
        role: '幫助寶寶學習自主進食'
      }
    ],
    momThoughts: '貝親的產品讓我不必在工作和育兒之間做出選擇。我可以全力投入工作，同時也能好好照顧我的寶寶。',
    relatedStories: ['story-1', 'story-4'],
    ageRange: '8-12個月',
    category: 'working-mom'
  },
  {
    id: 'story-3',
    title: '陳媽媽的雙寶進食訓練',
    subtitle: '同時照顧兩個寶寶，貝親產品是我的得力助手',
    familyName: '陳家',
    momName: '陳媽媽',
    babyAge: '1-2歲',
    babyName: '小安和小樂',
    familyBackground: '雙寶媽媽，全職照顧，丈夫經常加班',
    heroImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-2-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    storyContent: `照顧雙寶是一場馬拉松。陳媽媽每天都在時間管理和耐心之間尋找平衡。最大的挑戰？同時為兩個不同發展階段的寶寶準備食物。

小安已經1歲半，可以自己用餐具進食，而小樂才1歲，還在學習。「一開始我真的很崩潰，」陳媽媽笑著說，「但貝親的產品設計得很聰明，我可以為兩個寶寶準備不同的食物，同時也能確保他們都能安全地進食。」

現在，每到吃飯時間，陳媽媽會把兩個寶寶放在各自的高腳椅上，給他們各自的貝親餐具。小安專注地用叉子戳著食物，小樂則開心地用勺子挖著碗裡的食物。這一刻，混亂變成了和諧。`,
    keyMoments: [
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-2-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '雙寶一起進食的溫暖時刻'
      },
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-1-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '小安和小樂各自享受自己的食物'
      }
    ],
    products: [
      {
        id: 'product-5',
        name: '多功能餐具組',
        role: '適應不同發展階段寶寶的需求'
      },
      {
        id: 'product-6',
        name: '防滑碗盤',
        role: '讓寶寶安全地進食，媽媽放心'
      }
    ],
    momThoughts: '雙寶的挑戰很大，但貝親的產品讓我能夠更有效率地照顧他們。看著他們一起成長，所有的辛苦都值得。',
    relatedStories: ['story-1', 'story-2'],
    ageRange: '12-24個月',
    category: 'multiple-kids'
  },
  {
    id: 'story-4',
    title: '李奶奶的代間照顧溫暖故事',
    subtitle: '用貝親產品傳遞三代人的愛',
    familyName: '李家',
    momName: '李奶奶',
    babyAge: '1.5歲',
    babyName: '小明',
    familyBackground: '退休奶奶主要照顧孫子，兒子兒媳都在上班',
    heroImage: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-4-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
    storyContent: `李奶奶已經60多歲了，但當小明出生的那一刻，她重新找到了生活的意義。作為主要照顧者，她承擔起了大部分的育兒責任。

「我那時代沒有這麼多好工具，」李奶奶說，「但現在有貝親，我可以更輕鬆地照顧小明。」貝親的產品設計得很人性化，即使是年紀較大的奶奶也能輕鬆使用。

每天下午，當小明放學回來，李奶奶都會用貝親的餐具為他準備營養的點心。小明坐在奶奶身邊，開心地吃著食物。這個簡單的日常，卻承載著三代人的愛。「看著小明健康成長，我覺得自己的努力都值得了。」`,
    keyMoments: [
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-4-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '奶奶和小明一起享受下午茶時光'
      },
      {
        image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663442092005/V96DZCm6qcmujFnXQZsvbd/scenario-1-hero-vLtQvKqHmL5v7nXQZsvbd.webp',
        caption: '代間的愛在餐桌上傳遞'
      }
    ],
    products: [
      {
        id: 'product-7',
        name: '易握餐具組',
        role: '方便奶奶和寶寶一起使用'
      },
      {
        id: 'product-8',
        name: '安全餐盤',
        role: '確保寶寶進食的安全'
      }
    ],
    momThoughts: '貝親的產品讓我能夠更好地照顧小明，也讓我感受到現代育兒工具的溫暖。我很感謝有這樣的幫助。',
    relatedStories: ['story-1', 'story-3'],
    ageRange: '12-24個月',
    category: 'grandparents'
  }
];

export function getStoryById(id: string): Story | undefined {
  return stories.find(story => story.id === id);
}

export function getStoriesByCategory(category: Story['category']): Story[] {
  return stories.filter(story => story.category === category);
}

export function getStoriesByAgeRange(ageRange: string): Story[] {
  return stories.filter(story => story.ageRange === ageRange);
}

export function getRelatedStories(storyId: string, limit: number = 3): Story[] {
  const story = getStoryById(storyId);
  if (!story) return [];
  
  return story.relatedStories
    .map(id => getStoryById(id))
    .filter((s): s is Story => s !== undefined)
    .slice(0, limit);
}

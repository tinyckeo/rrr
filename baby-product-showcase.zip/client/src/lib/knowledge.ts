export interface KnowledgeArticle {
  id: string;
  title: string;
  ageRange: string;
  category: 'milestone' | 'nutrition' | 'technique' | 'safety' | 'faq';
  content: string;
  icon: string;
  relatedProducts: string[];
  relatedStories: string[];
  expert?: string;
}

export interface ExpertAdvice {
  id: string;
  expertName: string;
  expertTitle: string;
  topic: string;
  content: string;
  ageRange: string;
  icon: string;
}

export const knowledgeArticles: KnowledgeArticle[] = [
  {
    id: 'knowledge-1',
    title: '4-6個月：副食品入門指南',
    ageRange: '4-6個月',
    category: 'milestone',
    icon: '🥣',
    content: `寶寶滿4-6個月時，就可以開始嘗試副食品了。這是寶寶人生中重要的一步，標誌著他開始探索除了母乳或配方奶之外的食物。

**準備工作：**
- 確保寶寶能夠坐直，對食物感興趣
- 準備合適的高腳椅和餐具
- 選擇易消化的食物（如米糊、蔬菜泥）

**開始方式：**
- 每次只嘗試一種新食物
- 等待3-5天，觀察是否有過敏反應
- 從小量開始，逐漸增加

**常見食物：**
- 米糊（最常見的第一食物）
- 馬鈴薯泥
- 南瓜泥
- 蘋果泥`,
    relatedProducts: ['product-1', 'product-2'],
    relatedStories: ['story-1'],
    expert: '李醫生'
  },
  {
    id: 'knowledge-2',
    title: '6-8個月：食物多樣化',
    ageRange: '6-8個月',
    category: 'nutrition',
    icon: '🥗',
    content: `當寶寶適應了初期的副食品後，就可以逐漸引入更多種類的食物。這個階段的目標是讓寶寶習慣不同的味道和口感。

**推薦食物：**
- 蔬菜：胡蘿蔔、綠花椰菜、豌豆
- 水果：香蕉、梨、桃子
- 穀物：燕麥、小米
- 蛋白質：豆類、雞肉（確保煮軟）

**餵食技巧：**
- 每天可以嘗試新食物
- 觀察寶寶的反應
- 如果寶寶不喜歡，不要強迫
- 可以混合不同食物增加風味

**營養需求：**
- 鐵質：支持寶寶的發育
- 鈣質：骨骼發展
- 蛋白質：肌肉成長`,
    relatedProducts: ['product-3', 'product-4'],
    relatedStories: ['story-1', 'story-2'],
    expert: '王營養師'
  },
  {
    id: 'knowledge-3',
    title: '8-10個月：自主進食的開始',
    ageRange: '8-10個月',
    category: 'technique',
    icon: '🍴',
    content: `這個階段的寶寶開始對自己進食感興趣。他們可能會試圖抓住食物或湯匙。這是鼓勵自主進食的好時機。

**自主進食的好處：**
- 發展手眼協調能力
- 建立獨立性
- 增加對食物的興趣
- 學習咀嚼技能

**準備工作：**
- 提供易握的食物（軟的、不易窒息的）
- 使用適合寶寶手的餐具
- 準備好清潔用品（會很髒！）
- 穿上圍兜保護衣服

**食物選擇：**
- 軟的水果塊（香蕉、梨）
- 蒸軟的蔬菜
- 軟的穀物食物
- 避免堅硬或圓形的食物

**安全提示：**
- 始終在寶寶身邊監督
- 不要給寶寶單獨進食
- 確保食物大小合適`,
    relatedProducts: ['product-5', 'product-6'],
    relatedStories: ['story-2', 'story-3'],
    expert: '陳育兒專家'
  },
  {
    id: 'knowledge-4',
    title: '10-12個月：獨立進食訓練',
    ageRange: '10-12個月',
    category: 'technique',
    icon: '🎉',
    content: `寶寶現在已經準備好更獨立地進食了。他們可能想要自己拿著湯匙或叉子，雖然可能還不太熟練。

**發展里程碑：**
- 用手指拿起小食物
- 試圖用湯匙進食（可能會灑出來）
- 喝水時可能會溢出
- 開始理解「吃」的概念

**鼓勵獨立進食：**
- 提供合適大小的餐具
- 讓寶寶看著你進食
- 耐心等待，不要急著幫忙
- 表揚每一次嘗試

**飲食多樣化：**
- 逐漸引入家庭食物
- 減少泥狀食物
- 增加咀嚼的機會
- 注意鹽和糖的攝入

**常見挑戰：**
- 食物灑落：正常現象，是學習過程
- 拒絕進食：可能只是不餓
- 挑食：繼續提供各種食物`,
    relatedProducts: ['product-7', 'product-8'],
    relatedStories: ['story-3', 'story-4'],
    expert: '李醫生'
  },
  {
    id: 'knowledge-5',
    title: '窒息風險和安全預防',
    ageRange: '4-24個月',
    category: 'safety',
    icon: '⚠️',
    content: `嬰幼兒窒息是一個嚴重的風險。了解如何預防和識別窒息風險至關重要。

**高風險食物（避免）：**
- 整粒堅果和種子
- 葡萄（應切成四份）
- 番茄（應切成四份）
- 硬糖或棒棒糖
- 爆米花
- 生胡蘿蔔
- 整個熱狗

**安全進食指南：**
- 食物應該軟到可以用手指輕易壓碎
- 圓形食物應切成四份
- 避免粘稠的食物（如花生醬）
- 確保寶寶坐直進食

**監督要點：**
- 始終在寶寶身邊
- 不要在寶寶進食時讓他跑動
- 避免分散注意力
- 教導寶寶慢慢咀嚼

**緊急情況：**
- 了解基本的急救知識
- 知道何時尋求醫療幫助
- 保持冷靜，快速反應`,
    relatedProducts: [],
    relatedStories: [],
    expert: '李醫生'
  },
  {
    id: 'knowledge-6',
    title: '常見過敏症狀和預防',
    ageRange: '4-24個月',
    category: 'safety',
    icon: '🤧',
    content: `食物過敏在嬰幼兒中相當常見。了解症狀和預防方法可以幫助您保護寶寶。

**常見過敏食物：**
- 花生和樹堅果
- 牛奶和乳製品
- 雞蛋
- 魚和貝類
- 大豆
- 小麥
- 芝麻

**過敏症狀：**
- 皮疹或蕁麻疹
- 嘔吐或腹瀉
- 腫脹（嘴唇、舌頭、喉嚨）
- 呼吸困難
- 嚴重情況下的過敏性休克

**預防策略：**
- 一次只引入一種新食物
- 等待3-5天觀察反應
- 記錄寶寶的飲食和反應
- 如果有家族過敏史，更要謹慎

**如果懷疑過敏：**
- 立即停止給予該食物
- 聯絡兒科醫生
- 進行過敏測試
- 尋求營養師的建議`,
    relatedProducts: [],
    relatedStories: [],
    expert: '王營養師'
  },
  {
    id: 'knowledge-7',
    title: '常見問題：寶寶不吃怎麼辦？',
    ageRange: '4-24個月',
    category: 'faq',
    icon: '❓',
    content: `許多父母擔心寶寶不吃足夠的食物。以下是一些常見情況和建議。

**情況1：寶寶拒絕新食物**
- 這很正常，需要多次嘗試
- 不要強迫，可以稍後再試
- 讓寶寶看著你吃，示範進食
- 可能需要10-15次嘗試才會接受

**情況2：寶寶進食量少**
- 確保寶寶真的餓了
- 不要過度餵食
- 觀察寶寶的飽足信號
- 如果寶寶健康成長，可能沒問題

**情況3：寶寶只吃某些食物**
- 繼續提供各種食物
- 不要只提供他喜歡的
- 逐漸引入新食物
- 與其他家庭成員一起進食

**何時尋求幫助：**
- 寶寶體重沒有增長
- 寶寶看起來沒有精神
- 寶寶有消化問題
- 你感到非常擔心`,
    relatedProducts: [],
    relatedStories: [],
    expert: '陳育兒專家'
  }
];

export const expertAdvices: ExpertAdvice[] = [
  {
    id: 'expert-1',
    expertName: '李醫生',
    expertTitle: '兒科醫生',
    topic: '副食品安全入門',
    content: '副食品的引入應該是一個漸進的過程。每次只引入一種新食物，並等待3-5天觀察是否有過敏反應。這樣可以幫助您識別寶寶對特定食物的反應。',
    ageRange: '4-6個月',
    icon: '👨‍⚕️'
  },
  {
    id: 'expert-2',
    expertName: '王營養師',
    expertTitle: '營養師',
    topic: '營養均衡飲食',
    content: '確保寶寶獲得足夠的鐵質、鈣質和蛋白質是這個階段的關鍵。多樣化的飲食可以幫助寶寶獲得所需的所有營養。',
    ageRange: '6-12個月',
    icon: '🥗'
  },
  {
    id: 'expert-3',
    expertName: '陳育兒專家',
    expertTitle: '育兒專家',
    topic: '自主進食訓練',
    content: '自主進食不僅是一項技能，更是寶寶獨立性發展的重要部分。雖然會很髒，但這是學習過程的一部分。耐心和鼓勵是關鍵。',
    ageRange: '8-12個月',
    icon: '👩‍🏫'
  }
];

export function getKnowledgeByAgeRange(ageRange: string): KnowledgeArticle[] {
  return knowledgeArticles.filter(article => article.ageRange === ageRange);
}

export function getKnowledgeByCategory(category: KnowledgeArticle['category']): KnowledgeArticle[] {
  return knowledgeArticles.filter(article => article.category === category);
}

export function getKnowledgeById(id: string): KnowledgeArticle | undefined {
  return knowledgeArticles.find(article => article.id === id);
}

export function getExpertAdviceByAgeRange(ageRange: string): ExpertAdvice[] {
  return expertAdvices.filter(advice => advice.ageRange === ageRange);
}
